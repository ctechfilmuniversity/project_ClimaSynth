class RBFPoint {
  constructor(_pos, _rin, _rout, _expo,_col ){
    this.pos = _pos;
    this.rin = _rin; 
    this.rout = _rout; 
    this.expo = _expo; 
    this.col = _col;
    
    if(_pos.length != 2) {print("Point position must be 2 coordinates")}                       if(_col.length != 3) {print("Point color must be 3 channels");}
  }
  move(_x, _y){
    this.pos = [_x,_y];
  }
  render(_dimx, _dimy, _isSelected){
     noFill()
      stroke(255);
      
      strokeWeight(2);
      if(_isSelected ){strokeWeight(5);}
      
      circle(this.pos[0]*_dimx-(_dimx*0.5), this.pos[1]*_dimy-(_dimy*0.5), 10);
  }
  renderText(_t, _font)
  {
    stroke(255);
    strokeWeight(2);
    textAlign(CENTER, BOTTOM);
    textFont = _font;
    text(this.posX, this.posY)
  }
  posX(){
    return this.pos[0];
  }
  posY(){
  return this.pos[1];
  }
  posVector(){
    return createVector(this.pos[0], this.pos[1],0);
  }
  
  calculateExpo(_scaler){
    if(this.rin == 0 || this.rout == 0)
    {return 1;}
    let dd1 = this.rin;
  
	if(dd1 == 0){
	dd1 = 0.00000001;
	}
	let dd2 = this.rout;

	if((dd1 / dd2) <= 1 && (dd1 / dd2) >= THRESH){
		dd1 = THRESH * dd2;
	}else if((dd1 / dd2) >= 1 && (dd1 / dd2) <= (1 / THRESH)){
		dd1 = dd2 / THRESH;
      }
        let w = exp(-((log(2) + log(5)) * (log(dd1) + log(dd2))) / (log(dd1) - log(dd2)));
    w *= _scaler; 
    this.expo = w;
  }
  
}

class RBFCursor{
  constructor(_pos, _dimX, _dimY, _points)
  {
   this.pos = _pos;
   this.dim = [_dimX, _dimY]; 
   this.points = _points; //can initialize with empty array
   this.weights = [];
   this.changeFlag = false; //set when moved; reset when weights read;
  }
  
   move(_newPos)
  {
    this.pos = _newPos;
    this.changeFlag = true; 
   
  }
     move(_x, _y)
  {
    this.pos = [_x, _y];
     this.changeFlag = true;
    
  }
  posX()
  {
    return this.pos[0];
  }
   posY()
  {
    return this.pos[1];
  }
  posVector()
  {
    return createVector(this.pos[0], this.pos[1], 0);
  }
  posPix()
  {
    //scale position to canvas pixel size;
    let resX = this.posX()*this.dim[0]-(this.dim[0]*0.5);
    let resY =this.posY()*this.dim[1]-(this.dim[1]*0.5);
    let res = [resX, resY];
    return res;
  }
  
  render()
  {
    this.weights = this.calculateWeights(); //do it less often!
    
    
    let canvSpaceX = this.posPix()[0];
    let canvSpaceY = this.posPix()[1];
    let filCol =250
    fill(filCol);
    noStroke();
    strokeWeight(2);
    ellipseMode(CENTER)
    circle(canvSpaceX, canvSpaceY, 17 ); 
    
   
 
    
  }
  getWeights(_points)
  {
    this.changeFlag = false; 
    return this.weigths;
  }
  renderWeights()
  {
    let weights = this.weights;
    let points = this.points;
    let dim = this.dim;
    let start = this.posPix();
    let end;
   
    for(i = 0; i<points.length; i++)
      {
        point = points[i];
        
        end = points[i].posVector(); 
        end.x = end.x*dim[0]-(dim[0]*0.5);
        end.y = end.y*dim[1]-(dim[1]*0.5);
        let circlePos = end.copy();
        end = end.sub(start);
        end = end.mult(weights[i]);
        end = end.add(start);
        
        
        circlePos =  circlePos.sub(start);
        
         circlePos =  circlePos.mult(constrain(weights[i]*1.8,0,1));
       
         circlePos =  circlePos.add(start);
        
        fill(255,255,255, 255*pow(weights[i],1.7));
        noStroke();
        circle( circlePos.x, circlePos.y,7*weights[i]+2); 
        
        noFill();
        let strokecol = (50*sin(millis()/((abs(1-weights[i])*300)+100)))+100
        stroke(150*weights[i]+150,150*weights[i]+150,150*weights[i]+150, strokecol );
        strokeWeight(4*weights[i]+1);
        strokeCap(SQUARE)
        line(start[0], start[1], end.x, end.y); 
        
      }
    
  }
  calculateWeights()
  {
    let points = this.points;
    let result;
    let curs = this.posVector();
    let dist = [];
  
    for(i = 0; i<points.length; i++)
      {
        let pointPos = points[i].posVector();
        let pointRin = points[i].rin;
        
        pointPos.sub(curs);
        dist[i] = pointPos.mag(); 
       
      //  if(dist[i]<pointRin)
      //  { dist[i] = 0;}
      //  else
      //  {dist[i]-= pointRin;}
        //apply windowing
        dist[i] = pow(2.71828, -1*pow(points[i].expo*dist[i],2)); 
        
        
        
      }
  
  result =  this.normalizeArray(dist);
  this.weights = result;
  return result;  
  }
  
  normalizeArray(_array)
{
  let inArray = _array;
  let sum = 0;
  
  for(i =0; i<inArray.length; i++)
  {
    sum+= _array[i];
  }
  
  for(i =0; i<inArray.length; i++)
  {
    inArray[i] *= 1/sum;  
  }
  
  return inArray;
}
  
}
// end classes


///////////////////////////////////////

const THRESH = 0.9;
let firstFrame = true;
let screen;
let graphics ;
let RBFShader;
const dim = [600, 600];

let points = 
    [
      new RBFPoint ([0.1, 0.1], 0.01, 0.89, 3, [1.0, 0.5, 0.0]  ),
      new RBFPoint ([0.2, 0.2], 0.1, 0.89, 10, [0.0, 1.0, 0.2]  ),
      new RBFPoint ([0.3, 0.3], 0.2, 0.8, 5, [0.0, 0.0, 1.0]  ),
      new RBFPoint ([0.1, 0.7], 0.14, 0.9, 7, [1.0, 0.0, 0.3]  ),
      new RBFPoint ([0.5, 0.5], 0.2, 1.0, 10, [0.0, 0.0, 0.0]  )  
    ]
let cursor = new RBFCursor([0.5, 0.5], dim[0], dim[1], points );
    
let pointsPointer = 0;
let pointSelectElement;
let pointRadInElement;
let pointRadOutElement;

let exposScale = 100;



function preload()
{
  RBFShader = loadShader('RBFshader.vert', 'RBFshader.frag');
  
}
function setup() {
  
  pixelDensity(1);  
  screen = createCanvas(dim[0], dim[1], WEBGL);
  graphics = createGraphics(dim[0], dim[1], WEBGL);
  makeUI();
}

function draw() {  
  
  if(firstFrame){
    updateExpos();
    updatePoints();
  }
  
  RBFShader.setUniform('u_eff1', abs(1-(0.3*cos(millis()*0.001))));
  drawRBF();
  drawPoints();
  drawCursor();
}

function mouseDragged()
{
   
 if(mouseButton == LEFT && mouseOverCanvas())
 {
  movePoint();
 }
  else if (mouseButton == CENTER && mouseOverCanvas())
 {
   cursor.move(mouseX/dim[0], mouseY/dim[1]);
 }
  
}
function mousePressed()
{
  
 if(mouseButton == LEFT && mouseOverCanvas())
 {
   pointsPointer =  findNearestPointId(createVector(mouseX/dim[0], mouseY/dim[1],0)); 
   pointSelectElement.value(pointsPointer);
   eventPointSelect(pointsPointer);
 }
  else if (mouseButton == CENTER && mouseOverCanvas())
 {
   cursor.move(mouseX/dim[0], mouseY/dim[1]);
 }
}
function mouseOverCanvas()
{
  if(mouseX >= 0 && mouseX < width && mouseY >= 0 && mouseY < height  )
    {
      return true;
    }
  else {return false;}
}

function drawRBF()
{
  RBFShader.setUniform('u_resolution', [dim[0], dim[1]]);
  graphics.shader(RBFShader);
  graphics.push();
  graphics.rect(0,0,dim[0], dim[1]);
  resetShader();
  image(graphics, -dim[0]/2, -dim[1]/2, dim[0], dim[1]);
  graphics.pop();
}

function drawCursor()
{
  
  cursor.render(dim[0], dim[1]);
  cursor.renderWeights();
}
function drawPoints()
{
 // clear()
  
  
  for(i = 0; i<points.length; i++)
    {
        points[i].render(dim[0], dim[1]); 
    
    }
   
}


function updatePoints()
{
  RBFShader.setUniform('u_numPoints', points.length);
  
  let coords = [];
  let colors = [];
  let expos = [];
  let rins =[];
  let routs= [];
  
  for (i = 0; i<points.length; i++ )
    {
      coords[i*2] = points[i].posX();
      coords[i*2+1] = points[i].posY();
      
      colors[i*3] = points[i].col[0];
      colors[i*3+1] = points[i].col[1];
      colors[i*3+2] = points[i].col[2];
      
      expos[i] = points[i].expo;
      rins[i] = points[i].rin;
      routs[i] = points[i].rout;
    }
  
  RBFShader.setUniform('u_points', coords);
  RBFShader.setUniform('u_colors', colors);
  RBFShader.setUniform('u_expos', expos);
  RBFShader.setUniform('u_rin', rins);
  
  
}

function findNearestPointId(_pos)
{
  let nearest = 0;
   let dist = 10000000;
  for (i=0; i<points.length; i++)
    {
      let pos = points[i].posVector();
      let d = pos.sub(_pos);
      if(pos.mag()<dist){dist = d.mag(); nearest = i;}
      
    }
  
  return nearest;
}
function numPoints()
{
  return points.length;
}


function movePoint()
{
  
  if(mouseX>=0 && mouseX < width && mouseY >= 0 && mouseY < height){
    points[pointsPointer].move(mouseX/dim[0], mouseY/dim[1]);
  
   updatePoints();
  }
}

function updateExpos()
{
  for(i = 0; i< points.length; i++)
  {
    points[i].calculateExpo(exposScale)
  }
  
}

// document UI functions
function eventRadInSlider()
{
  points[pointsPointer].rin =  pointRadInElement.value()/256;
  updateExpos();
  updatePoints();
}
function eventRadOutSlider()
{
  points[pointsPointer].rout =  pointRadOutElement.value()/256;
  updateExpos();
  updatePoints();
}

function createPointsSelect()
{
  let sel = createSelect();
  populatePointsSelect(sel)
  sel.changed(eventPointSelect);
  return sel;
}
function eventPointSelect(val)
{
  pointsPointer = pointSelectElement.value();
  pointRadInElement.value(points[pointsPointer].rin*255);
  pointRadOutElement.value(points[pointsPointer].rout*255);
}
function populatePointsSelect(sel)
{
 let element = sel;
 let html ="";
  for(i = 0; i<points.length; i++)
    {
      element.option(i);
    }
}

function makeUI()
{
  pointSelectElement = createPointsSelect();
  
  pointRadInElement = createSlider(0,255, 0);
  pointRadInElement.changed(eventRadInSlider);

  pointRadOutElement = createSlider(0,255, 0);
  pointRadOutElement.html("out")
  pointRadOutElement.changed(eventRadOutSlider);
  
  eventPointSelect(0); 
}

function getWeigths()
{
  
  cursor.calculateWeights()
}